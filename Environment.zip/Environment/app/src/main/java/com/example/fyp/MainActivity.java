package com.example.fyp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;






public class MainActivity extends AppCompatActivity {
    EditText etEmail, etPassword;
    DatabaseReference reff;
    Button btnSave, btnDelete, btnUpdate;
    Member member;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toast.makeText(MainActivity.this, "Firebase connection success",Toast.LENGTH_LONG).show();


        etEmail=(EditText)findViewById(R.id.etEmail);
        etPassword=(EditText)findViewById(R.id.etPassword);
        reff= FirebaseDatabase.getInstance().getReference().child("Member");
        btnSave=(Button)findViewById(R.id.btnSave);
        btnDelete=(Button)findViewById(R.id.btnDelete);
        btnUpdate=(Button)findViewById(R.id.btnUpdate);
        member=new Member();


        // refernece for connecting and saving data to firebase https://www.youtube.com/watch?v=iy6WexahCdY&list=PLjMaHayx2gDG6bxZEoMuILMVv1Cv-6ua6&index=1
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                member.setEmail(etEmail.getText().toString().trim());
                member.setPassword(etPassword.getText().toString().trim());

                reff.push().setValue(member);

                Toast.makeText(MainActivity.this, "data inserted succesfully",Toast.LENGTH_LONG).show();


            }
        });

        // reference for deleting data https://www.youtube.com/watch?v=N39jM5KlOdk
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reff.child("-MLvmjyZgduGTq2NFNdT").removeValue();

                Toast.makeText(MainActivity.this, "data deleted succesfully",Toast.LENGTH_LONG).show();

            }
        });

        //reference for updating data https://www.youtube.com/watch?v=0HLyJNuyhSo
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email=etEmail.getText().toString();
                HashMap hashMap=new HashMap();
                hashMap.put("email", email);

                reff.child("-MLvmiJWa7iYQ5lx6WjI").updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        Toast.makeText(MainActivity.this, "data is successfully updated",Toast.LENGTH_LONG).show();
                    }
                });

            }
        });

    }
}
